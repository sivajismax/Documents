vim
===

An Ansible role to install Vim.

Requirements
------------

Assumes RedHat or Debian/Ubuntu OS families, and internet connectivity

Role Variables
--------------


Example Playbook
----------------

    - name: Example Playbook
      hosts: servers
      roles:
        - name: Install vim
          role: vim

License
-------

MIT

